# DOIP Command Center

Build "DOIP — Defense Operations Intelligence Platform": a military training &

simulation command-center web app. This is the COMPLETE FRONTEND with a built-in

mock simulation layer (no real backend yet). Architect a clean data-layer seam so

a FastAPI WebSocket backend can replace the mocks later without UI rewrites.

────────────────────────────────────────

DESIGN SYSTEM — use these exact tokens

────────────────────────────────────────

Dark command-center theme. Dense information layout. Monospace for ids,

timestamps, ticks, and coordinates.

Base colors:

- bg-base #0A0E14 (app background), bg-surface #111722 (panels/cards/sidebar),

  bg-raised #1A2230 (modals/dropdowns/hover), border #232D3F

- text-primary #E6EDF3, text-secondary #8B98A9, text-mono #9FB1C4

- NEVER pure black #000000, NEVER pure white #FFFFFF

Accents:

- accent #22D3EE (cyan): primary actions, links, selected nav, friendly units

- ai-violet #A78BFA: RESERVED EXCLUSIVELY for AI-generated content (sitrep

  cards, AI badges, What-If narration). Nothing else may use violet. Ever.

- success #34D399: ok states, passing checks, green posture

Severity system (color + shape ALWAYS paired):

- Low    ● #6B7A8F   - Medium ■ #FBBF24

- High   △ #FB923C   - Critical ◈ #F87171

Only critical (red) elements may pulse/animate. Nothing else blinks.

Map styling: dark tiles (CartoDB Dark Matter style); patrol zones dashed cyan

30% opacity; restricted zones red hatched 20%; threat zones orange gradient;

weather cells slate #64748B translucent 25-40% by intensity.

Every map view shows "© OpenStreetMap contributors".

Persistent chrome on every screen:

- Top status bar: sim clock, run status (RUNNING/PAUSED/REPLAY), tick rate,

  unacked alert count (badge), current user role.

- Footer: "Training & simulation platform. All data is synthetic. Not for

  operational military use."

- Left sidebar navigation, collapsible.

────────────────────────────────────────

MOCK SIMULATION LAYER (core requirement)

────────────────────────────────────────

A seeded pseudo-random tick engine in TypeScript (mulberry32 PRNG — same seed

produces the same run) generating a world every second: ~20 units (patrol teams,

UAVs, convoy vehicles, depots) with callsigns (ALPHA-1, RAVEN-2...) moving on

patrol routes around Bengaluru coordinates (lon 77.5x, lat 12.9x); weather cells

that drift and slow units inside them; incidents; resource consumption

(fuel/medkit/rations/battery); personnel vitals (heart rate, fatigue).

Every state change is a typed Event {id, tick, simTime, type, severity,

entityId, payload} appended to an in-memory immutable log. ALL screens read

only from this event stream and a derived state store — no screen owns data.

ROLES: mock login with four roles — admin, planner, operator, viewer.

planner+ plans missions; operator+ acknowledges alerts and controls runs;

admin sees the admin screen; viewer is read-only everywhere.

────────────────────────────────────────

15 SCREENS

────────────────────────────────────────

S1 Login — dark minimal, role picker for demo.

S2 Dashboard — KPI cards (active units, open incidents by severity, unacked

   alerts, stock warnings), mini map, recent events list.

S3 Live Map (home) — full-bleed Leaflet map: unit markers moving each tick,

   incident markers with severity shapes, weather overlays, zones; collapsible

   right-side event ticker; click any marker → context panel with details,

   recent events, and actions. Units silent 3+ min render hollow (stale).

S4 Run Control — scenario picker (SC-1 Night Patrol Baseline, SC-2 Border

   Surveillance, SC-3 Counter-UAV Airspace Watch, SC-4 Convoy Escort...), seed

   input, start/pause/resume/stop, speed 1-8x, tick counter, event-rate sparkline.

S5 Mission Planner — drop waypoints on map, draw survey zones; naive route vs

   optimized route side by side with cost breakdown (terrain/threat/weather);

   feasibility checklist (battery, endurance, restricted zones) gating a LAUNCH

   button — disabled until every check passes, with failure reasons listed.

S6 Replay — timeline scrubber with event-density heatstrip, jump-to-event list,

   1-8x playback of a finished run, rendered purely from the event log.

S7 AI Sitrep — violet AI cards: severity-ordered summary, every sentence ends

   with a citation chip [e:1234]; clicking a chip pulses that event's marker on

   an embedded map; "Generate Sitrep" button; unverified claims render in a

   flagged amber state, never as fact. Mock the LLM with canned summaries

   assembled from real events in the log.

S8 What-If Theater — prompt box ("storm hits sector C during the convoy run"),

   generated DSL action table (spawn_weather / create_incident / modify_speed /

   unit_report / raise_alert) with [edit | approve | discard] per row, then an

   animated condensed playback on the map with a violet narration panel and

   baseline-vs-what-if delta cards.

S9 Vision Review — frame viewer with placeholder aerial images, YOLO-style

   bounding boxes with confidence scores, accept/reject review queue, model

   version tag on every detection.

S10 Logistics — per-depot stock burn-down charts, forecast time-to-empty with

   warning bands, resupply task list.

S11 Personnel — roster grid (green/amber/red vitals bands), per-person trend

   sparklines, rotation suggestions when fatigue exceeds 0.8.

S12 Analytics — per-run KPIs (time-to-acknowledge, response times, comms-loss

   minutes), run-vs-run comparison on the same seed with delta highlighting.

S13 Investment Advisor — import summary card, ranked capability-gap register

   with evidence links, 2-3 portfolio cards under a budget slider, before/after

   re-simulation deltas, explicit "FACT" vs "PROJECTION" labels, footer

   disclaimer: "Decision-support analysis from simulation. Not a procurement

   directive."

S14 War-Room — shared map with mock multi-user cursors and annotations, role

   badges (Commander / Operator / Observer), task board with assign → ack →

   doing → done states.

S15 Admin — user/role table, append-only searchable audit log, scenario file

   list with validation status badges.

────────────────────────────────────────

QUALITY BAR

────────────────────────────────────────

- No dead buttons: everything clickable acts against the mock layer.

- Loading and empty states on every screen.

- '/' opens a global command palette.

- State management clean enough that swapping the mock tick engine for a

  WebSocket event feed is a single adapter change.

- Accessibility: severity is never conveyed by color alone (shapes + labels).

Start with the app shell, mock engine, S1, S3, and S4. Then build the rest.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/2738e9af-9a8e-451f-8ddb-f35fc7031546).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
